document.addEventListener("DOMContentLoaded", function() {
    const carouselItems = [
        {
            imgUrl: "https://picsum.photos/800/400?random=1",
            title: "Film 1",
            description: "Azione, Fantascienza, Avventura"
        },
        {
            imgUrl: "https://picsum.photos/800/400?random=2",
            title: "Film 2",
            description: "Fantasy, Azione, Dramma"
        },
        {
            imgUrl: "https://picsum.photos/800/400?random=3",
            title: "Film 3",
            description: "Drama, Storia"
        }
    ];

    const carouselContainer = document.getElementById("carousel-items");

    carouselItems.forEach((item, index) => {
        const activeClass = index === 0 ? 'active' : ''; 
        const carouselItem = `
            <div class="carousel-item ${activeClass}">
                <img src="${item.imgUrl}" class="d-block w-100" alt="${item.title}">
                <div class="carousel-caption d-none d-md-block">
                    <h5>${item.title}</h5>
                    <p>${item.description}</p>
                    <button class="btn btn-light">Guarda ora</button>
                    <button class="btn btn-outline-light">Altre info</button>
                </div>
            </div>
        `;
        carouselContainer.innerHTML += carouselItem;
    });
});



const films = [
    { title: "Film 1", genre: "Azione", duration: "120 min", image: "https://picsum.photos/400/300?random=1" },
    { title: "Film 2", genre: "Commedia", duration: "100 min", image: "https://picsum.photos/400/300?random=2" },
    { title: "Film 3", genre: "Dramma", duration: "130 min", image: "https://picsum.photos/400/300?random=3" },
    { title: "Film 4", genre: "Thriller", duration: "110 min", image: "https://picsum.photos/400/300?random=4" },
    { title: "Film 5", genre: "Fantasy", duration: "140 min", image: "https://picsum.photos/400/300?random=5" },
    { title: "Film 6", genre: "Azione", duration: "150 min", image: "https://picsum.photos/400/300?random=6" },
    { title: "Film 7", genre: "Horror", duration: "125 min", image: "https://picsum.photos/400/300?random=7" },
    { title: "Film 8", genre: "Avventura", duration: "115 min", image: "https://picsum.photos/400/300?random=8" },
    { title: "Film 9", genre: "Commedia", duration: "90 min", image: "https://picsum.photos/400/300?random=9" },
    { title: "Film 10", genre: "Dramma", duration: "160 min", image: "https://picsum.photos/400/300?random=10" },
    { title: "Film 11", genre: "Azione", duration: "110 min", image: "https://picsum.photos/400/300?random=11" },
    { title: "Film 12", genre: "Fantasy", duration: "120 min", image: "https://picsum.photos/400/300?random=12" },
    { title: "Film 13", genre: "Thriller", duration: "135 min", image: "https://picsum.photos/400/300?random=13" },
    { title: "Film 14", genre: "Commedia", duration: "105 min", image: "https://picsum.photos/400/300?random=14" },
    { title: "Film 15", genre: "Dramma", duration: "145 min", image: "https://picsum.photos/400/300?random=15" },
    { title: "Film 16", genre: "Azione", duration: "150 min", image: "https://picsum.photos/400/300?random=16" },
    { title: "Film 17", genre: "Horror", duration: "125 min", image: "https://picsum.photos/400/300?random=17" },
    { title: "Film 18", genre: "Avventura", duration: "130 min", image: "https://picsum.photos/400/300?random=18" },
    { title: "Film 19", genre: "Commedia", duration: "110 min", image: "https://picsum.photos/400/300?random=19" },
    { title: "Film 20", genre: "Dramma", duration: "140 min", image: "https://picsum.photos/400/300?random=20" }
];


function popolaSezione(idSezione, films) {
    const sectionContainer = document.getElementById(idSezione);
    films.forEach(film => {

        const imgContainer = document.createElement('div');
        imgContainer.classList.add('image-container');

        const img = document.createElement('img');
        img.src = film.image;
        img.alt = film.title;

        const overlay = document.createElement('div');
        overlay.classList.add('overlay');

        const rowButtons = document.createElement('div');
        rowButtons.classList.add('d-flex', 'justify-content-between', 'mb-3');

        const leftButtons = document.createElement('div');
        leftButtons.classList.add('d-flex', 'align-items-center');

        const buttonPlay = document.createElement('button');
        buttonPlay.classList.add('btn', 'btn-circle', 'btn-primary', 'mx-1', 'btn-custom');
        buttonPlay.innerHTML = `<ion-icon name="play"></ion-icon>`;
        leftButtons.appendChild(buttonPlay);

        const buttonPlus = document.createElement('button');
        buttonPlus.classList.add('btn', 'btn-circle', 'btn-primary', 'mx-1', 'btn-custom');
        buttonPlus.innerHTML = `<ion-icon name="add-circle"></ion-icon>`;
        leftButtons.appendChild(buttonPlus);

        const buttonThumbsUp = document.createElement('button');
        buttonThumbsUp.classList.add('btn', 'btn-circle', 'btn-primary', 'mx-1', 'btn-custom');
        buttonThumbsUp.innerHTML = `<ion-icon name="thumbs-up"></ion-icon>`;
        leftButtons.appendChild(buttonThumbsUp);

        const buttonB = document.createElement('button');
        buttonB.classList.add('btn', 'btn-circle', 'btn-secondary', 'btn-custom');
        buttonB.innerHTML = `<ion-icon name="chevron-down"></ion-icon>`; 

        rowButtons.appendChild(leftButtons);
        rowButtons.appendChild(buttonB);

        const infoContainer = document.createElement('div');
        infoContainer.classList.add('mt-2', 'text-center');

        const title = document.createElement('h5');
        title.textContent = film.title;

        const genre = document.createElement('p');
        genre.textContent = `Genere: ${film.genre}`;

        const duration = document.createElement('p');
        duration.textContent = `Durata: ${film.duration}`;

        infoContainer.appendChild(title);
        infoContainer.appendChild(genre);
        infoContainer.appendChild(duration);

        overlay.appendChild(rowButtons);
        overlay.appendChild(infoContainer);

        imgContainer.appendChild(img);
        imgContainer.appendChild(overlay);

        sectionContainer.appendChild(imgContainer);
    });
}
popolaSezione('laMiaLista', films);
popolaSezione('continuaGuardare', films);
popolaSezione('novita', films);
popolaSezione('commedie', films);
popolaSezione('imperdibili', films);


function enableMouseDragScroll() {
    const scrollContainers = document.querySelectorAll('.horizontal-scroll');

    scrollContainers.forEach(scrollContainer => {
        let isMouseDown = false;
        let startX, scrollLeft;

        scrollContainer.addEventListener('mousedown', (e) => {
            isMouseDown = true;
            startX = e.pageX - scrollContainer.offsetLeft; 
            scrollLeft = scrollContainer.scrollLeft;  
            scrollContainer.style.cursor = 'grabbing'; 
        });

        scrollContainer.addEventListener('mouseup', () => {
            isMouseDown = false;
            scrollContainer.style.cursor = 'grab';  
        });

        scrollContainer.addEventListener('mouseleave', () => {
            isMouseDown = false;
            scrollContainer.style.cursor = 'grab';  
        });

        scrollContainer.addEventListener('mousemove', (e) => {
            if (!isMouseDown) return;  
            e.preventDefault();  
            const x = e.pageX - scrollContainer.offsetLeft;  
            const walk = (x - startX) * 2;  
            scrollContainer.scrollLeft = scrollLeft - walk;  
        });
    });
}
enableMouseDragScroll();